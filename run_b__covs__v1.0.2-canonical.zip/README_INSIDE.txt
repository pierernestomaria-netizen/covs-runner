RUN_B canonical ZIP
