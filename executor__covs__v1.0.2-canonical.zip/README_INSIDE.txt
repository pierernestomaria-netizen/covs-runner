EXECUTOR canonical ZIP
