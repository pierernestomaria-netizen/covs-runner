# Canonical RUN_A (structure-complete)
