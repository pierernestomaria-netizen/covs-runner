RUN_A canonical ZIP
